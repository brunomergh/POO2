
public interface Observacao {
	
	public void EscreveObs();
	
}
